# Extended Angels
Extra buildings/recipies for angels mods </br>
Includes Copper Tungsten and Tungsten Carbide smelting using Angels Smelting </br>
Redone Tungsten Smelting 3</br>
Adds Tetrasodium Pyrophosphate to Tungsten Smelting 3 if MadClown01's processing is present </br>
Added Titanium Reinforced Brick </br>
Added Advanced Chemical Plant MK3 </br>
Added Adv Gas Refineray MK4 </br>
Added Agle Farm MK4 </br>
Added Hydro Plant MK4 </br>
Added Salation Plant MK3 </br>
Added Ore Washing Plant MK3 & MK4 </br>
Added Ore Crusher MK4, Floation Cell MK4, Leaching Plant MK4 & Ore Refineray MK3 </br>
Added Crystallizer and Filitration Unit MK3 </br>
Ported the Warehouse Addon Mod and added MK2-MK4 normal warhouses, buffer warehouses MK2-MK4 and tech changes </br>
Credits to Angels for his mods and for letting me have the graphics recoloured </br>
Zombiee for recolouring the graphics for me </br>
KorGgenT for his warehouse addon mod from 0.15 </br>
Thanks to MadClown01 with some brainstorming and for using some icons </br>
Thanks to Pezzawinkle for some bugfixes and Angels Componets support </br>
Thnanks to triktor for some bugfixes </br>
License for code is MIT </br>
License for grahpics is CC BY-NC-ND 4.0 </br>
